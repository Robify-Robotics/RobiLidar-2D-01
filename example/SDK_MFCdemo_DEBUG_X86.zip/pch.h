﻿// pch.h: This is the precompiled header file.
// The files listed below are compiled only once, improving the build performance of future builds.
// This also affects IntelliSense performance, including code completion and many code browsing features.
// However, if any of the files listed here are updated between builds, all of them will be recompiled.
// Do not add files here that are updated frequently; doing so negates the performance advantage.

#ifndef PCH_H
#define PCH_H

// Add headers to precompile here
#include "framework.h"

#endif //PCH_H
