﻿
// demo2Dlg.h: Header file
//
#include"sdk/standard_interface.h"
#pragma once


// Cdemo2Dlg dialog
class Cdemo2Dlg : public CDialogEx
{
// Construction
public:
	Cdemo2Dlg(CWnd* pParent = nullptr);	// Standard constructor

// Dialog data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DEMO2_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();

private:
	CListCtrl m_list;
	RunConfig* m_cfg;
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
