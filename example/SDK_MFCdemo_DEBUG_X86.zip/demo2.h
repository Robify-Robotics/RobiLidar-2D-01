﻿
// demo2.h: Main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "Include 'pch.h' before including this file to generate the PCH"
#endif

#include "resource.h"		// Main symbols


// Cdemo2App:
// See demo2.cpp for the implementation of this class
//

class Cdemo2App : public CWinApp
{
public:
	Cdemo2App();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern Cdemo2App theApp;
