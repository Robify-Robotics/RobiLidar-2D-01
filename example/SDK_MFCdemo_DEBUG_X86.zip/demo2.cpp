﻿
// demo2.cpp: Defines the class behavior for the application.
#include "pch.h"
#include "framework.h"
#include "demo2.h"
#include "demo2Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Cdemo2App

BEGIN_MESSAGE_MAP(Cdemo2App, CWinApp)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// Cdemo2App construction

Cdemo2App::Cdemo2App()
{
	// Support Restart Manager
	m_dwRestartManagerSupportFlags = AFX_RESTART_MANAGER_SUPPORT_RESTART;

	// TODO: Add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only Cdemo2App object

Cdemo2App theApp;


// Cdemo2App initialization

BOOL Cdemo2App::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application manifest specifies
	// ComCtl32.dll version 6 or later to enable visual styles.
	//Otherwise, window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes
	// that you want to use in the application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();


	AfxEnableControlContainer();

	// Create the shell manager in case the dialog contains
	// any shell tree view or shell list view controls.
	CShellManager *pShellManager = new CShellManager;

	// Activate the "Windows Native" visual manager to enable themes in MFC controls
	CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));

	// Standard initialization
	// If you are not using these features and want to reduce
	// the size of the final executable, remove the specific
	// initialization routines below that you do not need
	// Change the registry key used to store settings
	// TODO: Modify this string as appropriate,
	// for example, to your company or organization name
	SetRegistryKey(_T("应用程序向导生成的本地应用程序"));

	Cdemo2Dlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  closed with "OK"
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  closed with "Cancel"
	}
	else if (nResponse == -1)
	{
		TRACE(traceAppMsg, 0, "Warning: Dialog creation failed; the application will terminate unexpectedly.\n");
		TRACE(traceAppMsg, 0, "Warning: If you use MFC controls in the dialog, you cannot #define _AFX_NO_MFC_CONTROLS_IN_DIALOGS.\n");
	}

	// Delete the shell manager created above.
	if (pShellManager != nullptr)
	{
		delete pShellManager;
	}

#if !defined(_AFXDLL) && !defined(_AFX_NO_MFC_CONTROLS_IN_DIALOGS)
	ControlBarCleanUp();
#endif

	// Since the dialog has been closed, return FALSE to exit the application,
	//  rather than starting the application's message pump.
	return FALSE;
}

