﻿
// demo2Dlg.cpp: Implementation file
/*************************************************Main notes*********************************************************/
// Project configuration:
//C/C++->General->Additional Include Directories: file paths
//C/C++->General->SDL checks: Off
//C/C++->Precompiled Headers: Precompiled Header Off
/*************************************************Main notes*********************************************************/
#pragma warning(disable:4996)

#include "pch.h"
#include "framework.h"
#include "demo2.h"
#include "demo2Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// Cdemo2Dlg dialog



Cdemo2Dlg::Cdemo2Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DEMO2_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Cdemo2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST2, m_list);
}

BEGIN_MESSAGE_MAP(Cdemo2Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &Cdemo2Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &Cdemo2Dlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &Cdemo2Dlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &Cdemo2Dlg::OnBnClickedButton4)
//	ON_WM_ACTIVATE()
ON_WM_TIMER()
END_MESSAGE_MAP()


// Cdemo2Dlg message handlers

BOOL Cdemo2Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add the "About..." menu item to the system menu.

	// IDM_ABOUTBOX must be within the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog. The framework does this automatically
	//  when the application's main window is not a dialog.
	SetIcon(m_hIcon, TRUE);			// Set the large icon
	SetIcon(m_hIcon, FALSE);		// Set the small icon

	// TODO: Add extra initialization here

	DWORD dwstyle = m_list.GetExtendedStyle();
	dwstyle |= LVS_EX_FULLROWSELECT;
	dwstyle |= LVS_EX_GRIDLINES;
	m_list.SetExtendedStyle(dwstyle);

	m_list.InsertColumn(0, "IP/UART", LVA_ALIGNLEFT, 160);
	m_list.InsertColumn(1, "port/baud", LVA_ALIGNLEFT, 80);
	m_list.InsertColumn(2, "num", LVA_ALIGNLEFT, 60);
	m_list.InsertColumn(3, "timestamp", LVA_ALIGNLEFT, 200);

	SetTimer(1, 100, NULL);

	

	return TRUE;  // Return TRUE unless you set the focus to a control
}

void Cdemo2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you need the code below
//  to draw the icon. For MFC applications using the document/view model,
//  this is done automatically by the framework.

void Cdemo2Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center the icon in the client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//The system calls this function to obtain the cursor to display
//while the user drags the minimized window.
HCURSOR Cdemo2Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


/********************************************************************************Adjusted code**************************************************/

CArray<PointData, PointData&> m_datas;
void CallBackMsg(int msgtype, void* param)
{
	//Return real-time lidar data
	if (msgtype == 1)
	{
		PointData* pointdata = (PointData*)param;
		for (int i = 0; i < pointdata->N; i++)
		{
			printf("%s\t%d \t %d\t%.5f\t%.3f\t%d\n", pointdata->ip,pointdata->port, pointdata->N,pointdata->points[i].angle, pointdata->points[i].distance, pointdata->points[i].confidence);
		}
		//PointData* tmp = new PointData;
		//memcpy(tmp, param, sizeof(PointData));
		m_datas.Add(*pointdata);
	}
	//Return real-time protection zone data
	else if (msgtype == 2)
	{
		LidarMsgHdr* zone = (LidarMsgHdr*)param;
		uint32_t event = zone->events;
		std::string text;
		if (zone->flags % 2 == 1) {
			//Error information
			if (getbit(event, 0) == 1) {
				text += "Insufficient power supply";
			}
			if (getbit(event, 1) == 1) {
				text += "Motor stalled";
			}
			if (getbit(event, 2) == 1) {
				text += "Ranging module overtemperature";
			}
			if (getbit(event, 3) == 1) {
				text += "Network error";
			}
			if (getbit(event, 4) == 1) {
				text += "No output from ranging module";
			}
			if (getbit(event, 5) == 1) {
				text += "Angle abnormal";
			}
			if (getbit(event, 6) == 1) {
				text += "Ranging data abnormal";
			}
		}
		if (zone->flags >= 0x100) {
			//Protection zone information
			if (getbit(event, 12) == 1) {
				text += "Observation！！！";
			}
			if (getbit(event, 13) == 1) {
				text += "Warning！！！";
			}
			if (getbit(event, 14) == 1) {
				text += "Alarm！！！";
			}
			if (getbit(event, 15) == 1) {
				text += "Obstruction！";
			}
			if (getbit(event, 16) == 1) {
				text += "No data";
			}
			if (getbit(event, 17) == 1) {
				text += "No protection zone configured";
			}
			if (getbit(event, 18) == 1) {
				text += "Internal system error";
			}
			if (getbit(event, 19) == 1) {
				text += "Abnormal system operation";
			}
			if (getbit(event, 20) == 1) {
				//Duplicates the fourth item above; disabled here
				//text+='Network error\n'
			}
			if (getbit(event, 21) == 1) {
				text += "Device updating";
			}
			if (getbit(event, 22) == 1) {
				text += "Zero-position output";
			}
		}
		printf("Active zone:%d\tMSG:%s\n", zone->zone_actived, text.c_str());
	}
	//Get error information
	else if (msgtype == 3)
	{
		char* result = (char*)param;
		printf("Error Info : %s\n", result);

	}
	//Get lidar timestamp information for printing
	else if (msgtype == 4)
	{
		DevTimestamp* devtimestamp = (DevTimestamp*)param;
		printf("timestamp:lidar_ip:%s lidar_port:%d time:%d delay:%d\n", devtimestamp->ip, devtimestamp->port, devtimestamp->timestamp, devtimestamp->delay);
	}
}

//Print
void PrintMsg(int msgtype, void* param)
{

	//Get hardware device configuration information; the current serial version returns only the serial number, with other information empty
	if (msgtype == 2)
	{
		EEpromV101* eepromv101 = (EEpromV101*)param;
		//Type, number, serial number
		char tmp_sn[20] = { 0 };
		memcpy(tmp_sn, eepromv101->dev_sn, sizeof(eepromv101->dev_sn) - 1);
		char tmp_type[16] = { 0 };
		memcpy(tmp_type, eepromv101->dev_type, sizeof(eepromv101->dev_type) - 1);

		INFO_PR("dev info: Device number:%d\t Serial number:%s\t Type:%s\n", eepromv101->dev_id, tmp_sn, tmp_type);
		// IP address, subnet mask, gateway address, default destination IP, default destination UDP port, default external UDP service port
		char tmp_IPv4[16] = { 0 };
		char tmp_mask[16] = { 0 };
		char tmp_gateway[16] = { 0 };
		char tmp_srv_ip[16] = { 0 };

		sprintf(tmp_IPv4, "%d.%d.%d.%d", eepromv101->IPv4[0], eepromv101->IPv4[1], eepromv101->IPv4[2], eepromv101->IPv4[3]);
		sprintf(tmp_mask, "%d.%d.%d.%d", eepromv101->mask[0], eepromv101->mask[1], eepromv101->mask[2], eepromv101->mask[3]);
		sprintf(tmp_gateway, "%d.%d.%d.%d", eepromv101->gateway[0], eepromv101->gateway[1], eepromv101->gateway[2], eepromv101->gateway[3]);
		sprintf(tmp_srv_ip, "%d.%d.%d.%d", eepromv101->srv_ip[0], eepromv101->srv_ip[1], eepromv101->srv_ip[2], eepromv101->srv_ip[3]);

		INFO_PR("dev info: IP address:%s Subnet mask:%s Gateway address:%s Default destination IP:%s  Default destination UDP port:%d   Default external UDP service port:%d\n",
			tmp_IPv4, tmp_mask, tmp_gateway, tmp_srv_ip, eepromv101->srv_port, eepromv101->local_port);

		/*char tmp_ranger_bias[8] = {0};
		memcpy(tmp_ranger_bias, eepromv101->ranger_bias, sizeof(eepromv101->ranger_bias) - 1);*/
		//Rotation speed, motor startup parameters, FIR filter order, revolution count, resolution, automatic upload at startup, fixed upload, data point smoothing, trailing point removal, recorded correction coefficients, network heartbeat, recorded IO port polarity
		INFO_PR("dev info: Rotation speed:%d Motor startup parameters:%d FIR filter order:%d Revolution count:%d  Resolution:%d   Upload automatically at startup:%d Fixed upload:%d  Point smoothing:%d Trailing point removal:%d   Network heartbeat:%d  Record IO port polarity:%d\n",
			eepromv101->RPM, eepromv101->RPM_pulse, eepromv101->fir_filter, eepromv101->cir, eepromv101->with_resample, eepromv101->auto_start,
			eepromv101->target_fixed, eepromv101->with_smooth, eepromv101->with_filter, eepromv101->net_watchdog, eepromv101->pnp_flags);

		INFO_PR("dev info:Smoothing coefficient：%d  Active zone：%d  Uploaded data type：%d", eepromv101->deshadow, eepromv101->zone_acted, eepromv101->should_post);
	}
	//Set hardware configuration data; print OK on success    S_PACK
	else if (msgtype == 3)
	{
		DevData* devdata = (DevData*)param;
		for (int i = 0; i < sizeof(devdata->set) - 1; i++)
		{
			char buf[3] = { 0 };
			if (devdata->set[i] == '1')
			{
				memcpy(buf, devdata->result + 2 * i, 2);
				INFO_PR("DEV SET  index:%d  result:%s\n", i, buf);
			}
		}
	}
	fflush(stdout);
}





void Cdemo2Dlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	CString cfg_file_name = "LSS-40D-C30E.txt";
	m_cfg =new RunConfig;
	m_cfg->callback = CallBackMsg;
	if (!read_config(cfg_file_name, *m_cfg))
	{
		CString error = "config file is not exist " + cfg_file_name;
		MessageBox(error);
		return ;
	}

	//Start the lidar device; a nonzero return value indicates failure, and 0 indicates packet data can be received normally
	int res = openDev(*m_cfg, 0);
	if (res != 0)
	{
		CString error = "open dev failed";
		MessageBox(error);
		return;
	}
	getLidarData(m_cfg->thread_ID[1], true);
}


void Cdemo2Dlg::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here

	ControlDrv(m_cfg->thread_ID[1], "LSTARH");
	
}


void Cdemo2Dlg::OnBnClickedButton3()
{
	// TODO: Add your control notification handler code here
	ControlDrv(m_cfg->thread_ID[1], "LSTOPH");
}


void Cdemo2Dlg::OnBnClickedButton4()
{
	// TODO: Add your control notification handler code here
	ControlDrv(m_cfg->thread_ID[1], "LRESTH");
}



void Cdemo2Dlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call the default handler

	CDialogEx::OnTimer(nIDEvent);

	if (m_list.GetItemCount() > 100)
	{
		for (int i = 0; i < m_list.GetItemCount() - 100; i++)
		{
			m_list.DeleteItem(i);
		}
	}
	int num = m_list.GetItemCount();
	//if (m_datas.GetSize() < 100)
	{
		for (int i = 0; i < m_datas.GetSize(); i++)
		{
			PointData data = m_datas.GetAt(i);

			CString port;
			port.Format("%d", data.port);

			CString N;
			N.Format("%d", data.N);

			CString ts;
			ts.Format("%d %d", data.ts[0], data.ts[1]);
		
			m_list.InsertItem(i+ num, _T(""));
			m_list.SetItemText(i+ num, 0, data.ip);
			m_list.SetItemText(i+ num, 1, port);
			m_list.SetItemText(i+ num, 2, N);
			m_list.SetItemText(i+ num, 3, ts);
			//To get all point cloud data, refer to the iteration below
			/*for(int j=0;j<data.N;j++)
			{
				float angle =data.points[i].angle;
				int confidence = data.points[i].confidence;
				float distance = data.points[i].distance;
			}*/
		}
		m_datas.RemoveAll();
	}
}


