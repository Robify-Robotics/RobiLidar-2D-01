﻿#ifndef __STANDARD_INTERFACE_H__
#define __STANDARD_INTERFACE_H__

#include"../sdk/service/ZoneAlarm.h"
#include"LidarDataProcess.h"
#include"error.h"
#ifdef _WIN32

#elif __unix__ 
#include <sys/ipc.h>
#include <sys/msg.h>
#endif

#define SDKVERSION   "2.2"  //SDK version number

/************************************************
* @functionName:  read_config
* @date:          2022-03-28
* @description:   CN:Read and parse the input configuration file  EN:Read and parse incoming configuration files
* @Parameter:	  
				  1.cfg_file_name[const char*,IN]	            CN:Configuration file path	EN:config file path
				  2.cfg[RunConfig,OUT]			CN:Structure for saving configuration information	EN:Structure: save configuration information

* @return:        true/false
* @others:        Null
*************************************************/
bool read_config(const char* cfg_file_name, RunConfig& cfg);


/************************************************
* @functionName:  openDev
* @date:          2022-03-28
* @description:   CN:Start the lidar  EN:start lidar
* @Parameter:
				  1.cfg[const RunConfig,OUT]			CN:Configuration file data			 EN:config file data

* @return:        Socket handle or file handle
* @others:        Null
*************************************************/
int openDev(RunConfig& cfg, int index);
/************************************************
* @functionName:  thread_set_run
* @date:          2022-05-05
* @description:   CN:Child thread starts the lidar  EN:child thread start lidar
* @Parameter:
				  1.cfg[const RunConfig,OUT]			CN:Configuration file data			 EN:config file data

* @return:        linux  0 success  other failed    win32   >0 success  <=0 failed
* @others:        Null
*************************************************/
int thread_set_run(RunConfig& cfg);
/************************************************
* @functionName:  getLidarData
* @date:          2022-05-05
* @description:   CN:Get lidar data for printing  EN:Get printed data from lidar
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.dataGet	[bool,IN]   CN:Printing switch			   EN:is print?
* @return:        0  success   !=0  false
* @others:        get data from allback function 
*************************************************/
int getLidarData(long threadID,bool dataGet);

/************************************************
* @functionName:  GetDevInfo
* @date:          2022-05-05
* @description:   CN:Get device configuration data  EN:Get device configuration data
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.data	[EEpromV101,OUT]   CN:Lidar point data  EN:lidar points data
* @return:        0  success   !=0  false
* @others:        Null
*************************************************/
int GetDevInfo(long threadID, EEpromV101& data);
/************************************************
* @functionName:  SetDevInfo_extre
* @date:          2022-05-05
* @description:   CN:Set device configuration parameters  EN:Set device configuration data
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.data	[DevData,IN/OUT]   CN:Set lidar parameters  EN:set lidar config
* @return:        0
* @others:        Null
*************************************************/
int SetDevInfo_extre(long threadID, DevData &data);

/************************************************
* @functionName:  GetLidarTimestamp
* @date:          2022-05-05
* @description:   CN:Get lidar timestamp information  EN:Get lidar timestamp information
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.dataGet	[bool,IN]   CN:Printing switch			   EN:is print?
* @return:        0
* @others:        Null
*************************************************/
int GetLidarTimestamp(long threadID, bool dataGet);

/************************************************
* @functionName:  GetAlarmZone
* @date:          2022-07-27
* @description:   CN:Get zone data  EN:Get zone data
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.data	[RecvZoneDatas,OUT]   CN:Protection zone information			   EN:zone info
* @return:        0  success   !=0  false
* @others:        Null
*************************************************/
int GetAlarmZone(long threadID, RecvZoneDatas&data);
/************************************************
* @functionName:  SetAlarmZone
* @date:          2022-07-27
* @description:   CN:Set protection zoneData  EN:Set zone data
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.data	[zones,IN]   CN:Protection zone information			   EN:zone info
* @return:        0  success   !=0  false
* @others:        Null
*************************************************/
int SetAlarmZone(long threadID, zones &data);
/************************************************
* @functionName:  StopDrv
* @date:          2022-03-28
* @description:   CN:Stop the lidar  EN:stop lidar
* @Parameter:
				  1.run[RunConfig,OUT]			CN:Configuration file data			 EN:config file data

* @return:        Null
* @others:        Null
*************************************************/
void StopDrv(RunConfig* run);

/************************************************
* @functionName:  ControlDrv
* @date:          2022-03-28
* @description:   CN:Set the lidar to start or pause  EN:Set the lidar on or off
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.data	[const char*,IN]   CN:Lidar start/stop ranging command	EN:conctrl lidar cmd
* @return:        
* @others:        Null
*************************************************/
int ControlDrv(long threadID, const char*data);

/************************************************
* @functionName:  getVersion
* @date:          2022-05-09
* @description:   CN:Get version number  EN:get version
* @Parameter:	  Null
* @return:        const char* 
* @others:        Null
*************************************************/
const char* getVersion();
/************************************************
* @functionName:  ZoneSection
* @date:          2022-10-18
* @description:   CN:Read/set the active zone  EN:get/set alarmzone  section
* @Parameter:	  1.threadID [long,IN]  CN:Child thread ID/message queue ID  EN:Child thread ID/message queue ID
*				  2.section	[int,IN]   CN:Active zone index	EN:Active zone serial number
* @return:        3.mode[int,IN]     CN: 0 read, 1 set the active zone EN:0 Read 1 Set the active zone
* @others:        Null
*************************************************/
int ZoneSection(long threadID,int section,int mode);


//Open the local service (web test visualization page)
void  OpenLocalService(RunConfig& cfg, int index);
//Close the local service
void  CloseLocalService();

int GetOnePoint_MSG(long threadID, PointData& data);
extern RunConfig *g_cfg[MAX_LIDARS];


#endif