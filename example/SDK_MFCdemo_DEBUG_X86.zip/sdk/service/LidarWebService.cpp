﻿#include "LidarCheckService.h"
#include "LidarWebService.h"
#include "ZoneAlarm.h"
#include "standard_interface.h"
static const char *s_debug_level = "2";
static const char *s_root_dir = "web";
static const char *s_enable_hexdump = "no"; 
static const char *s_ssi_pattern = "*";
mg_connection *g_c;
LidarCheckService *g_checkservice;
LidarWebService::LidarWebService(int port)
{
	m_port = port;
	g_checkservice= new LidarCheckService(CHECKSERVICE);
}

LidarWebService::~LidarWebService()
{
	delete []g_checkservice;
}

void LidarWebService::OpenLocalService(int index)
{
	char address[64] = {0};
	sprintf(address, "http://0.0.0.0:%d", m_port);
	struct mg_mgr mgr;						 // Event manager
	mg_log_set("2");						 // Set to 3 to enable debug
	mg_mgr_init(&mgr);						 // Initialise event manager

	mg_http_listen(&mgr, address, fn, &index); // Create HTTP listener
	for (;;)
		mg_mgr_poll(&mgr, 50); // Infinite event loop
	mg_mgr_free(&mgr);
	INFO_PR("Lidar service is open success\n");
}

void LidarWebService::CloseLocalService()
{
}
static char *jsonValue(const char *result, const char *message, cJSON *array)
{
	if (array == NULL)
		array = cJSON_CreateArray();
	cJSON *root = cJSON_CreateObject();
	cJSON *item = cJSON_CreateString(result);
	cJSON_AddItemToObject(root, "result", item);
	item = cJSON_CreateString(message);
	cJSON_AddItemToObject(root, "message", item);

	cJSON_AddItemToObject(root, "data", array);
	char *out = cJSON_Print(root);
	cJSON_Delete(root);
	return out;
}

static void EEpromV101ToStr(EEpromV101 *eepromv101, char *version, char *result)
{
	cJSON *root = cJSON_CreateObject();
	//Type, number, serial number
	char tmp_sn[20] = {0};
	memcpy(tmp_sn, eepromv101->dev_sn, sizeof(eepromv101->dev_sn) - 1);
	char tmp_type[16] = {0};
	memcpy(tmp_type, eepromv101->dev_type, sizeof(eepromv101->dev_type) - 1);
	cJSON *item = cJSON_CreateNumber(eepromv101->dev_id);
	cJSON_AddItemToObject(root, "DID", item);
	item = cJSON_CreateString(tmp_sn);
	cJSON_AddItemToObject(root, "UID", item);
	item = cJSON_CreateString(tmp_type);
	cJSON_AddItemToObject(root, "NSP", item);
	/*INFO_PR("dev info: Device number:%d\t Serial number:%s\t Type:%s\n", eepromv101->dev_id, tmp_sn, tmp_type);*/
	// IP address, subnet mask, gateway address, default destination IP, default destination UDP port, default external UDP service port
	char tmp_IPv4[16] = {0};
	char tmp_mask[16] = {0};
	char tmp_gateway[16] = {0};
	char tmp_srv_ip[16] = {0};

	sprintf(tmp_IPv4, "%d.%d.%d.%d", eepromv101->IPv4[0], eepromv101->IPv4[1], eepromv101->IPv4[2], eepromv101->IPv4[3]);
	sprintf(tmp_mask, "%d.%d.%d.%d", eepromv101->mask[0], eepromv101->mask[1], eepromv101->mask[2], eepromv101->mask[3]);
	sprintf(tmp_gateway, "%d.%d.%d.%d", eepromv101->gateway[0], eepromv101->gateway[1], eepromv101->gateway[2], eepromv101->gateway[3]);
	sprintf(tmp_srv_ip, "%d.%d.%d.%d", eepromv101->srv_ip[0], eepromv101->srv_ip[1], eepromv101->srv_ip[2], eepromv101->srv_ip[3]);

	// INFO_PR("dev info: IP address:%s Subnet mask:%s Gateway address:%s Default destination IP:%s  Default destination UDP port:%d   Default external UDP service port:%d\n",
	//	tmp_IPv4, tmp_mask, tmp_gateway, tmp_srv_ip, eepromv101->srv_port, eepromv101->local_port);
	item = cJSON_CreateString(tmp_IPv4);
	cJSON_AddItemToObject(root, "IPv4", item);
	item = cJSON_CreateString(tmp_mask);
	cJSON_AddItemToObject(root, "mask", item);
	item = cJSON_CreateString(tmp_gateway);
	cJSON_AddItemToObject(root, "gateway", item);
	item = cJSON_CreateString(tmp_srv_ip);
	cJSON_AddItemToObject(root, "srv_ip", item);
	item = cJSON_CreateNumber(eepromv101->srv_port);
	cJSON_AddItemToObject(root, "srv_port", item);
	item = cJSON_CreateNumber(eepromv101->local_port);
	cJSON_AddItemToObject(root, "local_port", item);

	/*char tmp_ranger_bias[8] = { 0 };
	memcpy(tmp_ranger_bias, eepromv101->ranger_bias, sizeof(eepromv101->ranger_bias) - 1);*/

	int tmp_ranger_bias[6] = {0};
	for (int i = 0; i < 4; i++)
	{
		tmp_ranger_bias[i] = eepromv101->ranger_bias[i * 2 + 1];
		if (eepromv101->ranger_bias[i * 2])
			tmp_ranger_bias[i] *= -1;
	}
	//Rotation speed, motor startup parameters, FIR filter order, revolution count, resolution, automatic upload at startup, fixed upload, data point smoothing, trailing point removal, recorded correction coefficients, network heartbeat, recorded IO port polarity
	// sprintf(result,"dev info: rotation speed:%d motor startup parameters:%d FIR filter order:%d revolution count:%d resolution:%d automatic upload at startup:%d fixed upload:%d data point smoothing:%d trailing point removal:%d recorded correction coefficients:%s network heartbeat:%d recorded IO port polarity:%d\n",
	//	eepromv101->RPM, eepromv101->RPM_pulse, eepromv101->fir_filter, eepromv101->cir, eepromv101->with_resample, eepromv101->auto_start,
	//	eepromv101->target_fixed, eepromv101->with_smooth, eepromv101->with_filter, tmp_ranger_bias, eepromv101->net_watchdog, eepromv101->pnp_flags);
	item = cJSON_CreateNumber(eepromv101->RPM);
	cJSON_AddItemToObject(root, "RPM", item);

	item = cJSON_CreateNumber(eepromv101->RPM_pulse);
	cJSON_AddItemToObject(root, "PUL", item);

	item = cJSON_CreateNumber(eepromv101->fir_filter);
	cJSON_AddItemToObject(root, "FIR", item);

	item = cJSON_CreateNumber(eepromv101->cir);
	cJSON_AddItemToObject(root, "cir", item);

	item = cJSON_CreateNumber(eepromv101->with_resample);
	cJSON_AddItemToObject(root, "with_resample", item);

	item = cJSON_CreateNumber(eepromv101->auto_start);
	cJSON_AddItemToObject(root, "ATS", item);

	item = cJSON_CreateNumber(eepromv101->target_fixed);
	cJSON_AddItemToObject(root, "TFX", item);

	item = cJSON_CreateNumber(eepromv101->with_smooth);
	cJSON_AddItemToObject(root, "SMT", item);

	item = cJSON_CreateNumber(eepromv101->with_filter);
	cJSON_AddItemToObject(root, "DSW", item);

	item = cJSON_CreateIntArray(tmp_ranger_bias, 6);
	cJSON_AddItemToObject(root, "ERR", item);

	item = cJSON_CreateNumber(eepromv101->net_watchdog);
	cJSON_AddItemToObject(root, "net_watchdog", item);

	item = cJSON_CreateNumber(eepromv101->pnp_flags);
	cJSON_AddItemToObject(root, "PNP", item);

	item = cJSON_CreateNumber(eepromv101->deshadow);
	cJSON_AddItemToObject(root, "AF", item);

	item = cJSON_CreateNumber(eepromv101->should_post);
	cJSON_AddItemToObject(root, "PST", item);

	item = cJSON_CreateString(version);
	cJSON_AddItemToObject(root, "version", item);
	char *out = jsonValue("SUCCESS", "", root);
	sprintf(result, "%s", out);
	free(out);
}
void DevDataToStr(DevData *devdata, int index, char *value)
{
	memcpy(devdata->set + index, "1", 1);
	switch (index)
	{
	case 0:
		devdata->RPM = atoi(value);
		break;
	case 1:
		devdata->ERR = atoi(value);
		break;
	case 2:
		memcpy(&devdata->UDP, value, sizeof(devdata->UDP));
		break;
	case 3:
		memcpy(&devdata->DST, value, sizeof(devdata->DST));
		break;
	case 4:
		memcpy(&devdata->NSP, value, sizeof(devdata->NSP));
		break;
	case 5:
		memcpy(&devdata->UID, value, sizeof(devdata->UID));
		break;
	case 6:
		devdata->FIR = atoi(value);
		break;
	case 7:
		devdata->PUL = atoi(value);
		break;
	case 8:
		devdata->VER = atoi(value);
		break;
	case 9:
		devdata->PNP = atoi(value);
		break;
	case 10:
		devdata->SMT = atoi(value);
		break;
	case 11:
		devdata->DSW = atoi(value);
		break;
	case 12:
		devdata->DID = atoi(value);
		break;
	case 13:
		devdata->ATS = atoi(value);
		break;
	case 14:
		devdata->TFX = atoi(value);
		break;
	case 15:
		devdata->PST = atoi(value);
	case 16:
		devdata->AF = atoi(value);
		break;
	}
}
static void fn(struct mg_connection *c, int ev, void *ev_data, void *fn_data)
{
	int* cfg_index = (int*)fn_data;
	if (ev == MG_EV_HTTP_MSG)
	{
		struct mg_http_message *hm = (struct mg_http_message *)ev_data;
		if (mg_http_match_uri(hm, "/api/stats"))
		{
			cJSON *points = cJSON_CreateArray();
			cJSON *user;
			cJSON *item = cJSON_CreateNumber(1);
			for (struct mg_connection *t = c->mgr->conns; t != NULL; t = t->next)
			{
				char loc[40], rem[40];
				user = cJSON_CreateObject();
				item = cJSON_CreateNumber(t->id);
				cJSON_AddItemToObject(user, "ID", item);

				item = cJSON_CreateString(t->is_udp ? "UDP" : "TCP");
				cJSON_AddItemToObject(user, "type", item);

				item = cJSON_CreateString(t->is_listening ? "LISTENING" : t->is_accepted ? "ACCEPTED "
																						 : "CONNECTED");
				cJSON_AddItemToObject(user, "state", item);
				mg_straddr(&t->loc, loc, sizeof(loc));
				item = cJSON_CreateString(loc);
				cJSON_AddItemToObject(user, "loc", item);
				mg_straddr(&t->rem, rem, sizeof(rem));
				item = cJSON_CreateString(rem);
				cJSON_AddItemToObject(user, "rem", item);
				cJSON_AddItemToArray(points, user);
			}
			char *out = jsonValue("SUCCESS", "", points);
			mg_http_reply(c, 200, "", "%s", out);
			free(out);
			return;
		}

		else if (mg_http_match_uri(hm, "/init"))
		{
			cJSON *arr = cJSON_CreateArray();
			cJSON *point = cJSON_CreateObject();
			cJSON *item = cJSON_CreateString(g_cfg[*cfg_index]->type);
			cJSON_AddItemToObject(point, "type", item);
			std::string SYSType;
#ifdef _WIN32
			SYSType = "WIN32";
#elif __linux__
			SYSType = "LINUX";
#elif __APPLE__
			SYSType = "APPLE";
#endif
			item = cJSON_CreateString(SYSType.c_str());
			cJSON_AddItemToObject(point, "SDKENV", item);
			cJSON_AddItemToObject(arr, "", point);
			char *out = jsonValue("SUCCESS", "", arr);
			mg_http_reply(c, 200, "", "%s", out);
			free(out);
			return;
		}
		//Lidar action control
		else if (mg_http_match_uri(hm, "/action"))
		{
			cJSON *arr = cJSON_CreateArray();
			char query[256] = {0};
			memcpy(query, hm->query.ptr, hm->query.len);
			char *ret = strstr(query, "cmd=");
			if (!ret || strlen(ret + 4) != 6)
			{
				char *out = jsonValue("ERROR", "url is not current!", NULL);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
			char cmd[7] = {0};
			sprintf(cmd, "%s", ret + 4);
			ControlDrv(g_cfg[*cfg_index]->thread_ID[1], cmd);
			char *out = jsonValue("SUCCESS", "", NULL);
			mg_http_reply(c, 200, "", "%s", out);
			free(out);
			return;
		}
		//Lidar point cloud data/alarm information
		else if (mg_http_match_uri(hm, "/data"))
		{
			g_cfg[*cfg_index]->output_scan = true;
			PointData tmp;
			memcpy(&tmp, &g_cfg[*cfg_index]->pointdata, sizeof(PointData));
			if (tmp.N <= 0 || tmp.N > 10000)
			{
				char message[64] = { 0 };
				sprintf(message, "get point number unusual %d", tmp.N);
				char *out = jsonValue("ERROR", message, NULL);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
			cJSON *root = cJSON_CreateObject();
			cJSON *points = cJSON_CreateArray();
			cJSON *point;
			cJSON *item = cJSON_CreateNumber(tmp.N);
			cJSON_AddItemToObject(root, "N", item);
			if (strcmp(g_cfg[*cfg_index]->type, "uart") == 0 || strcmp(g_cfg[*cfg_index]->type, "vpc") == 0)
			{
				const int emptyarr[2] = {0, 0};
				item = cJSON_CreateIntArray(emptyarr, 2);
			}
			else
				item = cJSON_CreateIntArray((int *)tmp.ts, 2);
			cJSON_AddItemToObject(root, "ts", item);
			for (int i = 0; i < tmp.N; i++)
			{
				point = cJSON_CreateObject();
				item = cJSON_CreateNumber(tmp.points[i].angle * 180 / 3.1415926);
				cJSON_AddItemToObject(point, "angle", item);
				item = cJSON_CreateNumber(tmp.points[i].distance);
				cJSON_AddItemToObject(point, "distance", item);
				item = cJSON_CreateNumber(tmp.points[i].confidence);
				cJSON_AddItemToObject(point, "confidence", item);
				cJSON_AddItemToArray(points, point);
			}
			cJSON_AddItemToObject(root, "data", points);
			item = cJSON_CreateString("SUCCESS");
			cJSON_AddItemToObject(root, "result", item);
			item = cJSON_CreateString("");
			cJSON_AddItemToObject(root, "message", item);

			//Add zone-related data
			LidarMsgHdr zone;
			memcpy(&zone, &g_cfg[*cfg_index]->zone, sizeof(LidarMsgHdr));

			item = cJSON_CreateNumber(zone.flags);
			cJSON_AddItemToObject(root, "zone_flag", item);
			item = cJSON_CreateNumber(zone.events);
			cJSON_AddItemToObject(root, "zone_events", item);
			item = cJSON_CreateNumber(zone.zone_actived);
			cJSON_AddItemToObject(root, "zone_actived", item);

			char *out = cJSON_Print(root);
			mg_http_reply(c, 200, "", "%s", out);
			cJSON_Delete(root);
			free(out);
		}
		//Get lidar device information
		else if (mg_http_match_uri(hm, "/getDevinfo"))
		{
			EEpromV101 eepromv101;
			GetDevInfo(g_cfg[*cfg_index]->thread_ID[1], eepromv101);
			char info[1024] = {0};
			EEpromV101ToStr(&eepromv101, g_cfg[*cfg_index]->version, info); 
			mg_http_reply(c, 200, "", "%s", info);
			return;
		}
		//Set lidar device parameters 
		else if (mg_http_match_uri(hm, "/setDevinfo"))
		{
			memset(&g_cfg[*cfg_index]->pointdata, 0, sizeof(PointData));
			memset(&g_cfg[*cfg_index]->zone, 0, sizeof(LidarMsgHdr));

			if (strcmp(g_cfg[*cfg_index]->type, "uart") == 0)
			{
				char *out = jsonValue("ERROR", "uart is not support this function!", NULL);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
			char query[256] = {0};
			memcpy(query, hm->query.ptr, hm->query.len);
			std::string str = query;
			StringReplace(str, "%20", " ");
			int ret1 = str.find("index=");
			int ret2 = str.find("&value=");
			//Check whether the input string format is valid
			if (ret1 < 0 || ret2 < 0)
			{
				char *out = jsonValue("ERROR", "url is not current!", NULL);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
			int index = 0;
			index = atoi(str.substr(ret1 + 6, ret2 - ret1 - 6).c_str());
			//The input command value exceeds the limit
			if (index < 0 || index > 16)
			{
				char *out = jsonValue("ERROR", "url is not current!", NULL);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}

			std::string value = str.substr(ret2 + 7);
			DevData tmpData;
			memset(&tmpData, 0, sizeof(DevData));
			DevDataToStr(&tmpData, index, (char *)value.c_str());
			SetDevInfo_extre(g_cfg[*cfg_index]->thread_ID[1], tmpData);
			char buf[3] = {0};
			memcpy(buf, tmpData.result + 2 * index, 2);
			char *out = jsonValue("SUCCESS", buf, NULL);
			mg_http_reply(c, 200, "", "%s", out);
			free(out);
			return;
		}
		//Get the current lidar list; 0 indicates the child thread is running
		else if (mg_http_match_uri(hm, "/getLidarList"))
		{
			char query[256] = {0};
			memcpy(query, hm->query.ptr, hm->query.len);
			std::string str = query;
			StringReplace(str, "%20", " ");
			int ret1 = str.find("mode=");
			if (ret1 < 0)
			{
				char *out = jsonValue("ERROR", "url is not current!", NULL);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
			//Here, 0 opens the service and gets the current lidar list; 1 closes the service
			int index = atoi(str.substr(ret1 + 5, 1).c_str());
			if (index == 0)
			{
				// g_checkservice->openService();
				// g_checkservice->clearLidarsCache();
				std::vector<DevConnInfo> data = g_checkservice->getLidarsList();
				// printf("num:%d\n",data.size());
				cJSON *arr = cJSON_CreateArray();
				cJSON *point;
				cJSON *item;
				char conn_ip[16] = {0};
				short conn_port = 0;
				for (int i = 0; i < data.size(); i++)
				{
					point = cJSON_CreateObject();
					int type = data.at(i).type;
					item = cJSON_CreateNumber(data.at(i).type);
					cJSON_AddItemToObject(point, "type", item);

					item = cJSON_CreateString(data.at(i).com_port);
					cJSON_AddItemToObject(point, "com_port", item);

					item = cJSON_CreateNumber(data.at(i).com_speed);
					cJSON_AddItemToObject(point, "com_speed", item);

					if (type == 1)
					{
						DevInfo v1;
						memcpy(&v1, &data.at(i).info.v1, sizeof(DevInfo));
						sprintf(conn_ip, "%d.%d.%d.%d", v1.ip[0], v1.ip[1], v1.ip[2], v1.ip[3]);
						conn_port = v1.port;
					}
					else if (type == 2)
					{
						DevInfo2 v1;
						memcpy(&v1, &data.at(i).info.v1, sizeof(DevInfo2));
						sprintf(conn_ip, "%d.%d.%d.%d", v1.ip[0], v1.ip[1], v1.ip[2], v1.ip[3]);
						conn_port = v1.remote_udp;
					}
					else if (type == 3)
					{
						DevInfoV101 v1;
						memcpy(&v1, &data.at(i).info.v1, sizeof(DevInfoV101));
						sprintf(conn_ip, "%d.%d.%d.%d", v1.ip[0], v1.ip[1], v1.ip[2], v1.ip[3]);
						conn_port = v1.remote_udp;
					}
					item = cJSON_CreateString(conn_ip);
					cJSON_AddItemToObject(point, "conn_ip", item);
					item = cJSON_CreateNumber(conn_port);
					cJSON_AddItemToObject(point, "conn_port", item);

					char tmp[16] = {0};
					sprintf(tmp, "%s", data.at(i).timeStr);
					item = cJSON_CreateString(tmp);
					cJSON_AddItemToObject(point, "time", item);

					cJSON_AddItemToObject(arr, "", point);
				}
				char *out = jsonValue("SUCCESS", "", arr);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
			else if (index == 1)
			{
				g_checkservice->closeService();
				cJSON *item = cJSON_CreateArray();
				char *out = jsonValue("SUCCESS", "", item);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
			else
			{
				cJSON *item = cJSON_CreateArray();
				char *out = jsonValue("ERROR", "arg is not current!", item);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
				return;
			}
		}
		//Get the current lidar zone
		else if (mg_http_match_uri(hm, "/getZone"))
		{
			RecvZoneDatas results;
			cJSON *items = cJSON_CreateObject();
			char *out;
			if (GetAlarmZone(g_cfg[*cfg_index]->thread_ID[1], results))
			{
				out = jsonValue("ERROR", "get zone failed!", items);
				mg_http_reply(c, 200, "", "%s", out);
				free(out);
			}
			cJSON *arr = cJSON_CreateArray();
			cJSON *arr1;
			cJSON *arr2;
			cJSON *item = cJSON_CreateNumber(results.N);
			cJSON_AddItemToObject(items, "N", item);
			for (int i = 0; i < results.N; i++)
			{
				arr1 = cJSON_CreateObject();
				arr2 = cJSON_CreateArray();
				item = cJSON_CreateNumber(results.zoneData[i].type);
				cJSON_AddItemToObject(arr1, "type", item);
				item = cJSON_CreateNumber(results.zoneData[i].zoneID);
				cJSON_AddItemToObject(arr1, "zoneID", item);
				item = cJSON_CreateNumber(results.zoneData[i].outputID);
				cJSON_AddItemToObject(arr1, "outputID", item);
				item = cJSON_CreateNumber(results.zoneData[i].cnt);
				cJSON_AddItemToObject(arr1, "cnt", item);
				for (int j = 0; j < results.zoneData[i].cnt; j++)
				{
					double tt = results.zoneData[i].value[j];
					item = cJSON_CreateNumber(tt);
					cJSON_AddItemToObject(arr2, "", item);
				}
				cJSON_AddItemToObject(arr1, "value", arr2);
				cJSON_AddItemToObject(arr, "", arr1);
			}
			cJSON_AddItemToObject(items, "values", arr);
			out = jsonValue("SUCCESS", "", items);
			mg_http_reply(c, 200, "", "%s", out);
			free(out);
		}
		//Set the current lidar zone   post
		else if (mg_http_match_uri(hm, "/setZone"))
		{
			char result[1024] = {0};
			snprintf(result, hm->body.len + 1, "%s", hm->body.ptr);
			cJSON *root = cJSON_Parse(result);
			zones results;
			results.num = cJSON_GetArraySize(root);
			for (int i = 0; i < results.num; i++)
			{
				cJSON *svalue = cJSON_GetArrayItem(root, i);
				results.zoneArr[i].type = (POLYGON_TYPE)cJSON_GetObjectItem(svalue, "type")->valueint;
				results.zoneArr[i].zoneID = cJSON_GetObjectItem(svalue, "zoneID")->valueint;
				results.zoneArr[i].outputID = cJSON_GetObjectItem(svalue, "outputID")->valueint;
				results.zoneArr[i].arg1 = cJSON_GetObjectItem(svalue, "arg1")->valueint;
				results.zoneArr[i].arg2 = cJSON_GetObjectItem(svalue, "arg2")->valueint;
				results.zoneArr[i].arg3 = cJSON_GetObjectItem(svalue, "arg3")->valueint;
				results.zoneArr[i].arg4 = cJSON_GetObjectItem(svalue, "arg4")->valueint;
			}
			cJSON *item = cJSON_CreateArray();
			char *out;
			if (SetAlarmZone(g_cfg[*cfg_index]->thread_ID[1], results))
			{
				out = jsonValue("ERROR", "arg is not current!", item);
			}
			else
			{
				out = jsonValue("SUCCESS", "", item);
			}
			mg_http_reply(c, 200, "", "%s", out);
			free(out);
		}
		//Local resource file access
		else
		{
			mg_http_serve_opts opts = {0};
			opts.root_dir = s_root_dir;
			struct mg_http_message tmp = {0};
			mg_http_serve_dir(c, hm, &opts);
		}
	}
	else if (ev == MG_EV_WS_MSG)
	{
		g_c = c;
		mg_ws_send(c, "OK", 2, WEBSOCKET_OP_TEXT);
	}
	(void)fn_data;
}

void StringReplace(std::string &strBase, std::string strSrc, std::string strDes)
{
	std::string::size_type pos = 0;
	std::string::size_type srcLen = strSrc.size();
	std::string::size_type desLen = strDes.size();
	pos = strBase.find(strSrc, pos);
	while ((pos != std::string::npos))
	{
		strBase.replace(pos, srcLen, strDes);
		pos = strBase.find(strSrc, (pos + desLen));
	}
}
