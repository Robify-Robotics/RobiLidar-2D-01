﻿#pragma once

// Including SDKDDKVer.h defines the highest available Windows platform version.

//To build an application for an earlier Windows platform, include WinSDKVer.h and
// set the _WIN32_WINNT macro to the supported platform before including SDKDDKVer.h.

#include <SDKDDKVer.h>
